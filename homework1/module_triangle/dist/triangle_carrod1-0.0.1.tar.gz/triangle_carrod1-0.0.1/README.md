# Example Package

## Homework 1 -> area of a triangle module
