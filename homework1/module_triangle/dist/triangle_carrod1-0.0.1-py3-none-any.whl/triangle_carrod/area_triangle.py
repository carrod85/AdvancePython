def calculate_area(l, h):
    return l * h / 2
